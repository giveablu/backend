<?php

return [

    'authentication_key' => env('AUTHENTICATION_KEY', null)

];
